

// em = required / parent 

var calculate = () => {
  var parentVal = document.getElementById('parent').value;
  // console.log(parentVal); 
  var requiredVal = document.getElementById('required').value;
  // console.log(requiredVal);     
  var result = document.getElementById('result');

  // protect against empty fields resulting in NaN
  if(!parentVal | !requiredVal) {
    alert('Please fill in all fields...')
  } else {
    result.innerHTML = requiredVal / parentVal;
  }

}

var btn = document.querySelector('button');
btn.addEventListener('click', calculate);